/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.farmacia;

import javax.swing.JOptionPane;

/**
 *
 * @author angul
 */
public class PuntoDeVenta {

    String proveedor = "";
    String sucursal="";
    String tipoMedicamento="";
    public void getProveedor(String radio) {
        proveedor = radio;
    }
    public void getTipo(String boxTipo){
        tipoMedicamento=boxTipo;
    }

    public void getSucursal(String check) {
        String sucursal = check;
    }

    public void mostrarDatos() {
        JOptionPane.showMessageDialog(null,"Tipo de medicamento confirmado: " + tipoMedicamento);
        JOptionPane.showMessageDialog(null,"Proveedor confirmado: " + proveedor);
        JOptionPane.showMessageDialog(null, "Pedido confirmado");
    }
}
